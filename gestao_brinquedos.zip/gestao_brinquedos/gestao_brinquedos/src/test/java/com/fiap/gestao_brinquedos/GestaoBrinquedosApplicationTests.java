package com.fiap.gestao_brinquedos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GestaoBrinquedosApplicationTests {

	@Test
	void contextLoads() {
	}

}
