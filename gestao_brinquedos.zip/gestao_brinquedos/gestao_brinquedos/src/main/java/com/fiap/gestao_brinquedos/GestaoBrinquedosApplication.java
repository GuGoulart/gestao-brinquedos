package com.fiap.gestao_brinquedos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestaoBrinquedosApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestaoBrinquedosApplication.class, args);
	}

}
