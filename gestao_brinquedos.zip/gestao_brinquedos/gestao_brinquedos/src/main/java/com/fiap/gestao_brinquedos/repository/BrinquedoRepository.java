package com.fiap.gestao_brinquedos.repository;

import com.fiap.gestao_brinquedos.model.Brinquedo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BrinquedoRepository extends JpaRepository<Brinquedo, Long> {
}
