package com.fiap.gestao_brinquedos.controller;

import com.fiap.gestao_brinquedos.model.Brinquedo;
import com.fiap.gestao_brinquedos.repository.BrinquedoRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/brinquedos")
public class BrinquedoController {

    private final BrinquedoRepository repository;

    @Autowired
    public BrinquedoController(BrinquedoRepository repository) {
        this.repository = repository;
    }

    // GET /brinquedos
    @GetMapping
    public ResponseEntity<List<Brinquedo>> listarTodos() {
        List<Brinquedo> brinquedos = repository.findAll();
        return ResponseEntity.ok(brinquedos);
    }

    // GET /brinquedos/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Brinquedo> buscarPorId(@PathVariable Long id) {
        Optional<Brinquedo> brinquedo = repository.findById(id);
        return brinquedo.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    // POST /brinquedos
    @PostMapping
    public ResponseEntity<Brinquedo> criar(@Valid @RequestBody Brinquedo brinquedo) {
        Brinquedo salvo = repository.save(brinquedo);
        return ResponseEntity.ok(salvo);
    }

    // PUT /brinquedos/{id}
    @PutMapping("/{id}")
    public ResponseEntity<Brinquedo> atualizar(@PathVariable Long id, @Valid @RequestBody Brinquedo dadosAtualizados) {
        Optional<Brinquedo> existente = repository.findById(id);
        if (existente.isPresent()) {
            Brinquedo brinquedo = existente.get();
            brinquedo.setNome(dadosAtualizados.getNome());
            brinquedo.setTipo(dadosAtualizados.getTipo());
            brinquedo.setClassificacao(dadosAtualizados.getClassificacao());
            brinquedo.setTamanho(dadosAtualizados.getTamanho());
            brinquedo.setPreco(dadosAtualizados.getPreco());

            Brinquedo atualizado = repository.save(brinquedo);
            return ResponseEntity.ok(atualizado);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // DELETE /brinquedos/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletar(@PathVariable Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
